/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wctc.cw.week9.model;

import java.util.HashMap;
import java.util.Map;

/**
 *
 * @author L115student
 */
public class CartService {

    private static final Map<String, Cart> contents = new HashMap<>();

    public Cart getContents(String sessionId) {
        Cart cart = contents.computeIfAbsent(sessionId,
                (String t) -> new Cart());

//		ShoppingCart cart = contents.computeIfAbsent(sessionId,
//			new Function<String, ShoppingCart>() {
//			@Override
//			public ShoppingCart apply(String t) {
//				return new ShoppingCart();
//			}
//		});
        return cart;
    }

    public void update(String sessionId, Cart cart) {
        contents.put(sessionId, cart);
    }

    public void delete(String sessionId) {
        contents.remove(sessionId);
    }

}
