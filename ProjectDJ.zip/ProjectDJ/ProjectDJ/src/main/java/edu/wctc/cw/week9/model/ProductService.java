/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package edu.wctc.cw.week9.model;

import edu.wctc.dj.week9.data.ProductDAO;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 *
 * @author Chad Werning
 */
public class ProductService {

    public Product getProduct(String id) {
        // TODO
        return null;
    }

    public List<Product> getAllProducts() throws Exception {
        ProductDAO productDao = new ProductDAO();
        List<Product> productList = productDao.getProducts();

        return productList;

    }

    public List<Product> findProducts(String search) {
        // TODO
        return null;
    }

}
